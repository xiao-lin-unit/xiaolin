import requests
import json
import time
import base64
from gmssl import sm2

#作者：胡晨光、宋超群

#国密gmssl3.2.2版本
#python版本3.10.9

#样例代码仅供参考国密相关逻辑!!!
#样例代码仅供参考国密相关逻辑!!!
#样例代码仅供参考国密相关逻辑!!!
#样例代码仅供参考国密相关逻辑!!!

#16进制的公钥和私钥
#去掉公钥里的04
customer_priKey = '757266574E2E3DF1FB9151A5340D2C7176E36490687D2E877F2D2A48C09614AF'
customer_pubKey = '06B6ABCD935F2D095BC943797BDD2D274D5C7AB0CC6CEE8B701F6286BCBFFD6EF6F5FDEB34345C5B32224A4C3C50299314F52395A5AB11327D2B1ADE241278CF'
cbs8_pubKey = '157BF390F869EC724E9AB56D3B510B121879C9254DF8BA2E792AA05E64B518609D1EB05B9EE0CC0C932C9E8553224B1F7B00F99FF91C9CA3C2D74C144A77264E'
cbs8_domain = 'http://cbs8-openapi.csuat.cmburl.cn'
#mode传1, asn1传True
sm2_crypt = sm2.CryptSM2(public_key=cbs8_pubKey, private_key=customer_priKey, mode=1, asn1=True)
sm2_sign = sm2.CryptSM2(public_key=customer_pubKey, private_key=customer_priKey, mode=1, asn1=True)

#获取token，获取到的token有效期
payload = {'app_id': 'oK0i0rT8','app_secret': '152ab9a6af7d561763e2478343ce174999495cf4','grant_type': 'client_credentials'}
resp = requests.post(cbs8_domain + "/openapi/app/v1/app/token", data=json.dumps(payload))
jData = json.loads(resp.text)
print("token: ", jData['data']['token'], " 有效期", jData['data']['expires'])

#报文体
requestDataBytes='{\"accountNo\":\"\"}'

#时间戳，毫秒
timestamp=str(int(round(time.time() * 1000)))
requestDataBytes=bytes(requestDataBytes, 'utf-8')

#加签
signData=requestDataBytes+bytes("&timestamp="+timestamp, 'utf-8')
sign = sm2_sign.sign_with_sm3(signData)
#签名结果转为二进制，再进行base64
sign = base64.b64encode(bytes.fromhex(sign))

#报文体加密
enc_data = sm2_crypt.encrypt(requestDataBytes)

#sm2加密后，需要在最开始增加一个字节0x04
prefix = bytearray(1)
prefix[0] = 4
enc_data=prefix+enc_data

#发送报文
url = cbs8_domain + '/openapi/account/openapi/v1/account/query'
bearer='Bearer '+ jData['data']['token']

#请求头
headers = {"X-MBCLOUD-TIMESTAMP":timestamp,'Authorization':bearer,'X-MBCLOUD-API-SIGN':sign,'Content-Type': 'application/json'}
print("请求头",headers)

r = requests.post(url,headers=headers,data=enc_data)

#请在实际工程中判断请求是否成功

#sm2解密前，需要去掉最开始一个字节0x04
resp = r.content[1:]

decrypted = sm2_crypt.decrypt(resp)
print(str(decrypted))